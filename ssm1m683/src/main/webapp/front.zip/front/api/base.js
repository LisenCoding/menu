﻿const base = {
    url : "http://localhost:8080/ssm1m683/"
}
export default base
